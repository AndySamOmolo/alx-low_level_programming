#include <stdio.h>

/**
 * main - Prints quote
 *
 * Return: zero on success
 *
 */
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
