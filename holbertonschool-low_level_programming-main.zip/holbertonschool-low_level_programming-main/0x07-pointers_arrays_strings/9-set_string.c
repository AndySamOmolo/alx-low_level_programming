#include "holberton.h"
/**
 * set_string - set value of pointer a char
 *
 * @s: This is my entry to set
 * @to: This is my entry to copy
 */
void set_string(char **s, char *to)
{
	*s = to;
}
