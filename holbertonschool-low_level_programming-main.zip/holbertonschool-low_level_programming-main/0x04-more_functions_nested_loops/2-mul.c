#include "holberton.h"

/**
 * mul - Multiplicacion of two numbers
 *
 * @a: Number 1
 * @b: Number 2
 *
 * Return: Result between a * b
 **/

int mul(int a, int b)
{
	return (a * b);
}
