#include "holberton.h"

/**
 * add -  sum between two numbers
 *
 * @a : number one
 *
 * @b : number two
 * Return : sum
 **/

int add(int a, int b)
{
	return (a + b);
}
