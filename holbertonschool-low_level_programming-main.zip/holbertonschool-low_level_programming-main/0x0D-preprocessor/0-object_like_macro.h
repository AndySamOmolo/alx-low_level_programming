#ifndef HEADER_FILE
#define HEADER_FILE
#define SIZE 1024

#endif
