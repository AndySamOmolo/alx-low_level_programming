#include <stdio.h>
/**
 * main - print the name of my file
 *
 * Return: 0
 */
int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
