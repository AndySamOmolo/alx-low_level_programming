#ifndef HEADER_FILE
#define HEADER_FILE

#define ABS(X) ((X < 0) ? -(X) : (X))

#endif
