#ifndef HEADER_FILE
#define HEADER_FILE
#include<string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
unsigned int binary_to_uint(const char *b);
void print_binary(unsigned long int n);
int _putchar(char c);
#endif
