#include "holberton.h"

/**
 * _strlen - This function is equal to strlen
 *
 * @s: this is my entry
 *
 * Return: the las character
 */
int _strlen(char *s)
{
	int a;

	for (a = 0; s[a] != '\0' ; a++)
	{
	}
	return (a);
}

