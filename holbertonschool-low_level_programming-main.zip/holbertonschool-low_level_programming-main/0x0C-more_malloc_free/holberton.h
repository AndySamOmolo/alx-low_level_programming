#ifndef HEADER_FILE
#define HEADER_FILE
int *array_range(int min, int max);
void *_calloc(unsigned int nmemb, unsigned int size);
char *string_nconcat(char *s1, char *s2, unsigned int n);
int _putchar(char c);
void *malloc_checked(unsigned int b);

#endif
